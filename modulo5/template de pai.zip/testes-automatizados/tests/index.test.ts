describe("Esse é o meu primeiro teste", ()=>{
    test("Esse teste vai verificar uma string", ()=>{
        const nome: string = "rodrigo"

        expect(nome).toBe("rodrigo")
    })
})

